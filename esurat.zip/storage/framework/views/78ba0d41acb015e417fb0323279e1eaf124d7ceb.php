
<?php $__env->startSection('title'); ?>
    <title>List Surat Keluar</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('row'); ?>
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">List Surat Keluar</h4>
            <div class="row">
                <div class="col-12">
                    <?php if(session()->has('alert')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('alert')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="table-responsive">
                        <div class="text-right mb-2">
                            <a href="<?php echo e(url('surat_keluar/add')); ?>"><button type="button"
                                    class="btn btn-primary btn-rounded btn-fw"><i class="mdi mdi-plus btn-icon-prepend"></i>
                                    Tambah Surat Keluar</button></a>
                        </div>
                        <table id="order-listing" class="table">
                            <thead>
                                <tr>
                                    <th>Tgl Terima</th>
                                    <th>No Agenda</th>
                                    <th>No Surat</th>
                                    <th>Tgl Surat</th>
                                    <th>Ringkasan</th>
                                    <th>Dari</th>
                                    <th>Kepada</th>
                                    <th>Kode Klasifikasi</th>
                                    <th>Ket</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                                <?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($list->created_at); ?></td>
                                        <td><?php echo e($list->nomor_agenda); ?></td>
                                        <td><?php echo e($list->nomor_surat_keluar); ?></td>
                                        <td><?php echo e($list->tanggal_surat); ?></td>
                                        <td><?php echo e($list->deskripsi_surat_keluar); ?></td>
                                        <td><?php echo e($list->divisi->nama_divisi); ?></td>
                                        <td><?php echo e($list->kepada_surat_keluar); ?></td>
                                        <td><?php echo e($list->jenis_surat->kode_jenis_surat); ?></td>
                                        
                                        <td></td>
                                        <td>
                                            <a href="<?php echo e(url('surat_keluar/edit/' . $list->id . '')); ?>"
                                                class="btn btn-outline-info"><i class="mdi mdi-pencil"></i></a>
                                            
                                            <form action="<?php echo e(url('surat_keluar/delete/' . $list->id)); ?>" method="post"
                                                class="d-inline">
                                                <?php echo method_field('delete'); ?>
                                                <?php echo csrf_field(); ?>
                                                
                                                <button class="btn btn-outline-danger"
                                                    onclick="return confirm('Yakin Ingin Menghapus ?');"><i
                                                        class="mdi mdi-delete"></i></button>
                                            </form>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlist', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\esurat\resources\views/admin/surat_keluar/list.blade.php ENDPATH**/ ?>