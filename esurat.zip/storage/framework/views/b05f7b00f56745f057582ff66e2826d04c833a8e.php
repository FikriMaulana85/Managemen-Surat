 <!-- plugins:css -->
 <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/iconfonts/mdi/font/css/materialdesignicons.min.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/css/vendor.bundle.base.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/css/vendor.bundle.addons.css')); ?>">
 <!-- endinject -->
 <!-- plugin css for this page -->
 <!-- End plugin css for this page -->
 <!-- inject:css -->
 <link rel="stylesheet" href="<?php echo e(asset('assets/css/vertical-layout-light/style.css')); ?>">
 <!-- endinject -->
 <link rel="shortcut icon" href="<?php echo e(asset('/images/favicon.png')); ?>" />
<?php /**PATH C:\xampp\htdocs\esurat\resources\views/partials/css.blade.php ENDPATH**/ ?>