
<?php $__env->startSection('title'); ?>
    <title>Laporan Surat Masuk</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('row'); ?>
    <div class="card">
        <div class="card-header">
            <div class="row">
                <div class="col">
                    <h6 class="card-title">Cetak Laporan Surat Masuk</h6>
                </div>
            </div>
            <div class="card-body">
                <form id="formlaporan" action="<?php echo e(url('laporan/cetak_laporan_surat_masuk')); ?>" method="post">
                    <div class="row">
                        <?php echo csrf_field(); ?>
                        <div class="col-2 mt-1 ">
                            <span>Periode</span>
                        </div>
                        <div class="col-3">
                            <input type="date" name="tanggal_awal" id="tanggal_awal" class="form-control" required>
                        </div>
                        <div class="col-1 text-center" style="margin:5px -4% 0 -4%;"> <b>-</b> </div>
                        <div class="col-3">
                            <input type="date" name="tanggal_akhir" id="tanggal_akhir" class="form-control" required>
                        </div>
                        <div class="col-3 text-right">
                            <button type="submit" class="btn btn-md btn-primary"><i class="bi bi-printer-fill"></i>
                                Cetak
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlist', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\esurat\resources\views/admin/laporan/lapmasuk.blade.php ENDPATH**/ ?>