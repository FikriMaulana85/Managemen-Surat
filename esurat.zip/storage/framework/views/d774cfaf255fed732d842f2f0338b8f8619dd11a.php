
<?php $__env->startSection('title'); ?>
    <title>Dashboard</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('row'); ?>
    <div class="row">
        <div class="col-md-6 col-lg-3 grid-margin stretch-card">
            <div class="card bg-gradient-primary text-white text-center card-shadow-primary">
                <div class="card-body">
                    <h6 class="font-weight-normal">Total Divisi</h6>
                    <h2 class="mb-0"><?php echo e($totaldivisi); ?></h2>
                </div>
            </div>
        </div>

        <div class="col-md-6 col-lg-3 grid-margin stretch-card">
            <div class="card bg-gradient-danger text-white text-center card-shadow-danger">
                <div class="card-body">
                    <h6 class="font-weight-normal">Total Jenis Surat</h6>
                    <h2 class="mb-0"><?php echo e($totaljenissurat); ?></h2>
                </div>
            </div>
        </div>

        <div class="col-md-6 col-lg-3 grid-margin stretch-card">
            <div class="card bg-gradient-success text-white text-center card-shadow-success">
                <div class="card-body">
                    <h6 class="font-weight-normal">Total Surat Masuk</h6>
                    <h2 class="mb-0"><?php echo e($totalsuratmasuk); ?></h2>
                </div>
            </div>
        </div>

        <div class="col-md-6 col-lg-3 grid-margin stretch-card">
            <div class="card bg-gradient-warning text-white text-center card-shadow-warning">
                <div class="card-body">
                    <h6 class="font-weight-normal">Total Surat Keluar</h6>
                    <h2 class="mb-0"><?php echo e($totalsuratkeluar); ?></h2>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\esurat\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>