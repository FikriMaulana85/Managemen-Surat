  <!-- plugins:js -->
  <script src="<?php echo e(asset('assets/vendors/js/vendor.bundle.base.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendors/js/vendor.bundle.addons.js')); ?>"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="<?php echo e(asset('assets/js/off-canvas.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/hoverable-collapse.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/template.js')); ?>"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="<?php echo e(asset('assets/js/select2.js')); ?>"></script>
  <!-- End custom js for this page-->
<?php /**PATH C:\xampp\htdocs\esurat\resources\views/partials/js.blade.php ENDPATH**/ ?>