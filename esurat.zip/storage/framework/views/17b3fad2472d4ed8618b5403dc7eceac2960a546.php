
<?php $__env->startSection('title'); ?>
    <title>List Users</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('row'); ?>
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">List Users</h4>
            <div class="row">
                <div class="col-12">
                    <?php if(session()->has('alert')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('alert')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="table-responsive">
                        <div class="text-right mb-2">
                            <a href="<?php echo e(url('users/add')); ?>"><button type="button"
                                    class="btn btn-primary btn-rounded btn-fw"><i class="mdi mdi-plus btn-icon-prepend"></i>
                                    Tambah User</button></a>
                        </div>
                        <table id="order-listing" class="table">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Username</th>
                                    <th>Nama Lengkap</th>
                                    <th>Role</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                                <?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($list->username); ?></td>
                                        <td><?php echo e($list->nama_lengkap); ?></td>
                                        <td><?php echo e($list->role->nama_role); ?></td>
                                        <td>
                                            <a href="<?php echo e(url('users/edit/' . $list->id . '')); ?>"
                                                class="btn btn-outline-info"><i class="mdi mdi-pencil"></i></a>
                                            <form action="<?php echo e(url('users/delete/' . $list->id)); ?>" method="post"
                                                class="d-inline">
                                                <?php echo method_field('delete'); ?>
                                                <?php echo csrf_field(); ?>
                                                
                                                <button class="btn btn-outline-danger"
                                                    onclick="return confirm('Yakin Ingin Menghapus ?');"><i
                                                        class="mdi mdi-delete"></i></button>
                                            </form>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlist', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\esurat\resources\views/admin/users/list.blade.php ENDPATH**/ ?>